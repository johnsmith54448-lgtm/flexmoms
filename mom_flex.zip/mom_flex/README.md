# MomFlex final package

Edit js/config.js to change content and affiliate link.
